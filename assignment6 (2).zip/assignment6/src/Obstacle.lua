--[[
    GD50
    Angry Birds

    Author: Colton Ogden
    cogden@cs50.harvard.edu

    An Obstacle is any physics-based construction that forms the current level,
    usually shielding the aliens the player is trying to kill; they can form houses,
    boxes, anything the developer wishes. Depending on what kind they are, they are
    typically rectangular or polygonal.
]]

Obstacle = Class{}

function Obstacle:init(world, shape, x, y)
    self.shapeType = shape or 'horizontal'

    if self.shapeType == 'horizontal' then
        self.frame = 2
    elseif self.shapeType == 'vertical' then
        self.frame = 4
    elseif self.shapeType == 'square' then
        self.frame = 5
    elseif self.shapeType == 'triangle' then
        self.frame = 6
    end

    self.startX = x
    self.startY = y

    self.world = world

    self.body = love.physics.newBody(self.world, 
    self.startX or math.random(VIRTUAL_WIDTH), self.startY or math.random(VIRTUAL_HEIGHT - 35), 'dynamic')

        -- KA: Added gravity
        self.body:setGravityScale(2.0)
        
    -- assign width and height based on shape to create physics shape
    if self.shapeType == 'horizontal' then
        self.width = 110
        self.height = 35
    elseif self.shapeType == 'vertical' then
        self.width = 35
        self.height = 110
    elseif self.shapeType == 'square' then
        self.width = 70
        self.height = 70
    elseif self.shapeType == 'triangle' then
        self.width = 70
        self.height = 23
    end

    if self.shapeType == 'triangle' then
        self.shape = love.physics.newPolygonShape(-35, self.height, 0, 0, 35, self.height)
    else
        self.shape = love.physics.newRectangleShape(self.width, self.height)
    end

    self.fixture = love.physics.newFixture(self.body, self.shape)

    self.fixture:setUserData('Obstacle')
end

-- KA: Drawing out the hitboxes because I ran into an issue with my triangle shape
function Obstacle:debugDraw()
    love.graphics.setColor(1, 0, 0)
    love.graphics.polygon('line', self.body:getWorldPoints(self.shape:getPoints()))
    love.graphics.setColor(1, 1, 1)
end

function Obstacle:update(dt)

end

function Obstacle:render()
    love.graphics.draw(gTextures['stone'], gFrames['stone'][self.frame],
        self.body:getX(), self.body:getY(), self.body:getAngle(), 1, 1,
        self.width / 2, self.height / 2)

    -- self:debugDraw()
end